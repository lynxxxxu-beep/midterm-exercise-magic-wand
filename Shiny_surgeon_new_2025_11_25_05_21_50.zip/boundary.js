class Boundary{
  constructor(x,y,w,h,angle){
    this.w = w;
    this.h = h;
    let options = {
      friction: 0.5,
      restitution: 0.5,
      isStatic: true,
      angle: angle,
    }
    this.body = Bodies.rectangle(x,y,w,h,options);
    Composite.add(engine.world,[this.body])
  }
  
  show(){
    push();
    translate(this.body.position.x, this.body.position.y);
    rotate(this.body.angle)
    fill(100);
    rectMode(CENTER)
    rect(0,0, this.w, this.h)
    pop()
  }
  
  
}