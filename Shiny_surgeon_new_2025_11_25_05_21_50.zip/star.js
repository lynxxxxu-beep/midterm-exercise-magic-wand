class Star extends Ball{
  constructor(px, py, vx, vy){
    super(px, py, vx, vy);
    this.r = 20;
    this.c = color(random(200,255), random(200,255), random(0,80));
    this.rot = random(2*PI)
  }
  
  
  
  att(){
    let mousePos = createVector(mouseX-50, mouseY-50);
    let attraction = p5.Vector.sub(mousePos, this.position);
    attraction.limit(1)
    this.velocity.add(attraction)
    this.velocity.limit(10)
    
  }
  
  show(){
    push();
    translate(this.position.x, this.position.y);
    rotate(this.rot)
    scale(sin(frameCount*0.1), 1);
    let twinkletwinkle = color(255,255,random(0,255));
    fill(twinkletwinkle);
    let normalNum = 5
    stroke(0);
    strokeWeight(0);
    triangle(-2*normalNum, 0, 2*normalNum, 0, 0, this.r);
    triangle(-0.6180*normalNum, 1.9021*normalNum, 0.6180*normalNum, -1.9021*normalNum, 0.95106*this.r, 0.35102*this.r);
    triangle(0.6180*normalNum, 1.9021*normalNum, -0.6180*normalNum, -1.9021*normalNum, -0.95106*this.r, 0.35102*this.r);
    triangle(-1.6180*normalNum, 1.1756*normalNum, 1.6180*normalNum, -1.1756*normalNum, -0.58779*this.r, -0.80902*this.r);
    triangle(1.6180*normalNum, 1.1756*normalNum, -1.6180*normalNum, -1.1756*normalNum, 0.58779*this.r, -0.80902*this.r);
    
  
    pop();
    this.rot +=0.03;
    
  }
}