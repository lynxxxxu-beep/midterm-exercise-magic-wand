class Box extends Shape{
  
  constructor(px, py, vx, vy){
    super(px, py, vx, vy)
    this.w = random(5,20);
    this.h = random(5,20);
  }
  
  move(){
    this.position.add(this.velocity)
  }

  bounce(){
  if (this.position.x < this.w/2){
    this.position.x = this.w/2;
    this.velocity.x *=  -1;
  }else if (this.position.x > width - this.w/2){
    this.position.x = width - this.w/2;
    this.velocity.x *=  -1;
  }
  if (this.position.y < this.h/2){
    this.position.y = this.h/2;
    this.velocity.y *=  -1;
  }else if (this.position.y > height - this.h/2){
    this.position.y = height - this.h/2;
    this.velocity.y *=  -1;
    }
  }   

  show(){
    fill(this.c1);
    stroke(0);
    strokeWeight(0);
    rectMode(CENTER);
    rect(this.position.x, this.position.y, this.w, this.h);
  }


}