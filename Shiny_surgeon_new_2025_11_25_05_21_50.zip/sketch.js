let Engine = Matter.Engine, 
    Body = Matter.Body,
    Bodies = Matter.Bodies,
    Composite = Matter.Composite,
    Constraint = Matter.Constraint;
let engine;
let polygons = [];
let balls = [];
let boxes = [];
let wheels = [];
let sumShape = 30;
let wand;
let wheelConstraints = [];






function setup() {
  createCanvas(600, 650);
  engine = Engine.create();
  starCursor = new Star(mouseX, mouseY, random(-2,3), random(-3,3))
  
  for (let i = 0; i < sumShape; i++){
    balls[i] = new Ball(random(0,400), random(0,400), random(-4,4), random(-4,4));
    balls[i].velocity.limit(random(1,10));
    boxes[i] = new Box(random(0,400), random(0,400), random(-4,4), random(-4,4));
  }
  
  createWheels();
}





function createWheels() {
  wheels = [];
  wheelConstraints = [];
  
  for (let i = 0; i < 4; i++){
    let x = 80 + ((width - 160)/3 * i);
    let b = new Wheel(x, height/2);
    wheels.push(b);
  
    let fixPoint = {
      bodyA: b.body,
      pointA: { x: 0, y: 0 },
      pointB: { x: x, y: height*0.98 },
      length: 0.1,
      stiffness: 0.8
    };
  
    let constraint = Constraint.create(fixPoint);
    wheelConstraints.push(constraint);
    Composite.add(engine.world, constraint);
  }
}






function draw() {
  background('#3E148A'); 
  Engine.update(engine);
  
  
  wand = stroke('#FFC107');
  strokeWeight(8);
  line(mouseX-50, mouseY-50, mouseX+30, mouseY+20);
  
  starCursor.move();
  starCursor.bounce();
  starCursor.show();
  starCursor.att();
  
  for (let b of boxes){
    b.move();
    b.bounce();
    b.show();
    b.att(starCursor.position)
  }
  for (let b of balls){
    b.move();
    b.bounce();
    b.show();
    b.att(starCursor.position)
  }
  for (let p of polygons){
    p.show();
  }
  for (let w of wheels){
    w.show()
  }
  
  
}







function mousePressed(){
  fullscreen(true)
}





function mouseDragged(){
  polygons.push(new Polygon(mouseX-50, mouseY-50, random(3,8),random(0,10)))
}








function windowResized(){
  resizeCanvas(windowWidth, windowHeight);
  

  for (let w of wheels) {
    Composite.remove(engine.world, w.body);
  }
  for (let c of wheelConstraints) {
    Composite.remove(engine.world, c);
  }
  
  createWheels();
}