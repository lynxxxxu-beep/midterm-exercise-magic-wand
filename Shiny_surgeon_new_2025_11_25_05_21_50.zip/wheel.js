class Wheel {
  constructor(x, y) {
    this.c = color('#FFFFFF');
    let options = {
      friction: 0,
      restitution: 0.5
    };

    let size = width/4;

    this.bodyA = Bodies.rectangle(x, y - size/40, size, size/20, options);
    this.bodyB = Bodies.rectangle(x - size/40, y, size/20, size, options);
    this.body = Body.create({
      parts: [this.bodyA, this.bodyB]
    });
    
    Composite.add(engine.world, this.body);
  }
  
  show() {
    noStroke();
    fill(this.c);
    let size = width/3;
    
    let pos = this.body.position;
    let angle = this.body.angle;
    
    push();
    translate(pos.x, pos.y);
    rotate(angle);
    
    rect(0, -size/40, size, size/20);
    rect(-size/40, 0, size/20, size);
    
    pop();
  }
}