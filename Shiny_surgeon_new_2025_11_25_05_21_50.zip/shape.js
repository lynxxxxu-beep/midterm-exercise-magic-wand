class Shape{
  
  constructor(px,py,vx,vy){
    this.position = createVector(px, py)
    this.velocity = createVector(vx, vy)
    this.c1 = color(random(150,255),random(150,255),random(150,255),random(50))
    this.c2 = color(random(255),random(255),random(255),random(100))
  }
  
  applyForce(f){
    this.velocity.add(f);
    this.velocity.limit(15);
  }
  
  
  move(){
    this.position.add(this.velocity)
  }
  
  
  att(pos){
    let attraction = p5.Vector.sub(pos, this.position);
    attraction.limit(0.2)
    let noiseNum = 0.5
    let noise = createVector (random(-1*noiseNum,noiseNum), random(-1*noiseNum,noiseNum))
    attraction = p5.Vector.add(attraction, noise)
    this.velocity.add(attraction)
    this.velocity.limit(random(5,100))
  }
  
  

  
  
  
  
  
  
}