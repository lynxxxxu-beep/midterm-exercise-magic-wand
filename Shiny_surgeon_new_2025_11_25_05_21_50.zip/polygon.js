class Polygon extends physicShape{
  constructor(x,y,r,s){
    super();
    this.r = r;
    let options = {
      friction: 0,
      restitution: 0.9,
    }
    this.body = Bodies.polygon(x,y,r,s,options);
    Composite.add(engine.world, [this.body]);
  }
  
  show(){
    fill('#FFFFFF26');
    beginShape();
    for (let a of this.body.vertices){
      vertex(a.x, a.y);
    }
    endShape(CLOSE);
  }
}