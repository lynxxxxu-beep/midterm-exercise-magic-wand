class Ball extends Shape{
  
  constructor(px, py, vx, vy){
    super(px, py, vx, vy);
    this.r = random(5,100);
  }
  
  move(){
    this.position.add(this.velocity)
  }

  bounce(){
  if (this.position.x < this.r ){
    this.position.x = this.r ;
    this.velocity.x *=  -1
  }else if (this.position.x > width - this.r){
    this.position.x = width - this.r;
    this.velocity.x *=  -1    
  }
  if (this.position.y < this.r ){
    this.position.y = this.r ;
    this.velocity.y *=  -1    
  }else if (this.position.y > height - this.r){
    this.position.y = height - this.r;
    this.velocity.y *=  -1    
    }
  }   

  show(){
    
    push();
    translate(this.position.x, this.position.y);
    //rotate(random(-0.2*PI,0.2*PI))
    //rotateY(frameCount * 0.1);
    circle(0, 0, this.r * 2);
    stroke(0);
    strokeWeight(0);
    pop()
    
    fill(this.c2)
  }

  getPosition() {
    return { x: this.x, y: this.y };
  }
  
  getVelocity() {
    return { x: this.velocity.x, y: this.velocity.y };
  }

}