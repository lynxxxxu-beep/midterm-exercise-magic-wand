class physicShape {
  constructor(){
  }
  
  
  offScreen(){
    if (this.body.position.y>height*2){
      return true;
    }else{
      return false;
    }
  }
  
  
  delete(){
    Composite.remove(engine.world, [this.body]);
  }
  
}